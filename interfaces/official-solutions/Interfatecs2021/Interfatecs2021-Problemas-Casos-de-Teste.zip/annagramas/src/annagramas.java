
public class annagramas {
	public static void main(string args[]) {
		
	}
}
